﻿using System;

namespace SistemaCompra.Infra.Data.EF
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
