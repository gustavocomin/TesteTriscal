﻿namespace SistemaCompra.Domain.SolicitacaoCompraAggregate
{
    public enum Situacao
    {
        Solicitado = 1,
        Recebido = 2,
        Atendido = 3
    }
}