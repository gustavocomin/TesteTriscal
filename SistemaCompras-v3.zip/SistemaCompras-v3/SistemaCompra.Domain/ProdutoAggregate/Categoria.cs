﻿namespace SistemaCompra.Domain.ProdutoAggregate
{
    public enum Categoria
    {
        Madeira=1,
        Juncao=2,
        Fixadores=3
    }
}
