﻿namespace SistemaCompra.Domain.ProdutoAggregate
{
    public enum Situacao
    {
        Ativo = 1,
        Suspenso = 2
    }
}
