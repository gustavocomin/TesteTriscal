﻿using MediatR;

namespace SistemaCompra.CrossCutting.Bus.Event
{
    public interface IEvent : INotification
    {
    }
}
